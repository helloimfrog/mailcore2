//
//  MCOPROVIDER.h
//  mailcore2
//
//  Created by Pushkar Singh on 5/24/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#ifndef _MAILCORE__MCOPROVIDER_h
#define _MAILCORE__MCOPROVIDER_h

#import <MailCore/MCONetService.h>
#import <MailCore/MCOMailProvider.h>
#import <MailCore/MCOMailProvidersManager.h>
#import <MailCore/MCOAccountValidator.h>

#endif
